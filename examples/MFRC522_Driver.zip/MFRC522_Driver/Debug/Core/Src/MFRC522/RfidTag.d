Core/Src/MFRC522/RfidTag.o: ../Core/Src/MFRC522/RfidTag.c \
 ../Core/Src/MFRC522/RfidTag.h ../Core/Src/MFRC522/MFRC522.h
../Core/Src/MFRC522/RfidTag.h:
../Core/Src/MFRC522/MFRC522.h:
