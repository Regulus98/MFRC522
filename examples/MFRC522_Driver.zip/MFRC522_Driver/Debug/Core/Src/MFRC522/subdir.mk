################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/MFRC522/MFRC522.c \
../Core/Src/MFRC522/RfidTag.c 

OBJS += \
./Core/Src/MFRC522/MFRC522.o \
./Core/Src/MFRC522/RfidTag.o 

C_DEPS += \
./Core/Src/MFRC522/MFRC522.d \
./Core/Src/MFRC522/RfidTag.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/MFRC522/%.o Core/Src/MFRC522/%.su Core/Src/MFRC522/%.cyclo: ../Core/Src/MFRC522/%.c Core/Src/MFRC522/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I"D:/workspace_stm32/MFRC522_Driver/Core/Src/MFRC522" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src-2f-MFRC522

clean-Core-2f-Src-2f-MFRC522:
	-$(RM) ./Core/Src/MFRC522/MFRC522.cyclo ./Core/Src/MFRC522/MFRC522.d ./Core/Src/MFRC522/MFRC522.o ./Core/Src/MFRC522/MFRC522.su ./Core/Src/MFRC522/RfidTag.cyclo ./Core/Src/MFRC522/RfidTag.d ./Core/Src/MFRC522/RfidTag.o ./Core/Src/MFRC522/RfidTag.su

.PHONY: clean-Core-2f-Src-2f-MFRC522

